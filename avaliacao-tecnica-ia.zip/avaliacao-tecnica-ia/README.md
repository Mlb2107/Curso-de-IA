# Avaliação Técnica — Contraturno IA

Repositório com a resolução dos oito exercícios da avaliação e os arquivos do chatbot desenvolvidos em aula.

## Conteúdo do repositório

### Exercícios da avaliação
- `respostas.txt`: respostas objetivas e justificativas das oito questões.
- `questoes/questao_04.py`: soma números até a entrada `0`.
- `questoes/questao_07.py`: carrega um arquivo de contexto em UTF-8 e trata arquivo inexistente.
- `questoes/questao_08.py`: exemplo didático de histórico persistente com Streamlit.

### Projeto desenvolvido em aula
- `app.py`: interface web do chatbot com Streamlit.
- `chat_contexto.py`: chatbot de terminal, memória e comandos de conversa.
- `contexto.py`: leitura do arquivo de contexto, com limite de caracteres.
- `contexto.txt`: informações de exemplo do Café Python.
- `llm_memoria.py`: integração com a API de chat da Groq.
- `prompts.py`: prompt de sistema e montagem das instruções com contexto.

## Requisitos

- Python 3.10 ou superior
- Chave de API da Groq para executar o chatbot integrado

## Instalação

```bash
python -m venv .venv
```

Ative o ambiente virtual:

Windows:
```bash
.venv\\Scripts\\activate
```

Linux/macOS:
```bash
source .venv/bin/activate
```

Instale as dependências:

```bash
pip install -r requirements.txt
```

## Configuração da API

1. Copie `.env.example` para `.env`.
2. Preencha `GROQ_API_KEY` com sua chave da Groq.
3. Não compartilhe nem envie o arquivo `.env` ao GitHub.

## Executar o chatbot

Interface web com Streamlit:

```bash
python -m streamlit run app.py
```

Chat pelo terminal:

```bash
python chat_contexto.py
```

Teste isolado da integração com a API:

```bash
python llm_memoria.py
```

## Executar os exercícios

```bash
python questoes/questao_04.py
python questoes/questao_07.py
```

Para a questão 8, execute a interface Streamlit:

```bash
python -m streamlit run questoes/questao_08.py
```

## Observações técnicas

- O chatbot envia o histórico de mensagens à API para manter o contexto da conversa.
- O prompt de sistema é montado com as informações de `contexto.txt`.
- O histórico da interface web é armazenado em `st.session_state`.
- O arquivo `contexto.py` desenvolvido em aula limita o conteúdo a 6.000 caracteres para reduzir o consumo de tokens.
- `questoes/questao_07.py` mantém a implementação específica solicitada no enunciado, sem limite de tamanho.
- O modelo configurado no projeto é `openai/gpt-oss-20b`; a disponibilidade depende da API/provedor no momento da execução.

## Entrega

Antes de publicar, confirme que `.env` não está entre os arquivos versionados. Adicione também eventuais outros códigos de aula que não estejam neste pacote.
