"""Questão 8: exemplo de histórico persistente em uma sessão Streamlit."""

import streamlit as st


if "historico" not in st.session_state:
    st.session_state.historico = []

st.title("Chat — Histórico de mensagens")
st.caption("Exemplo de persistência de conversa com st.session_state.")


for mensagem in st.session_state.historico:
    with st.chat_message(mensagem["role"]):
        st.write(mensagem["content"])


pergunta = st.chat_input("Digite...")

if pergunta:
    st.session_state.historico.append(
        {"role": "user", "content": pergunta}
    )
    st.rerun()
