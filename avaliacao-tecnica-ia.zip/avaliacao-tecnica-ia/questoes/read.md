Questão 1 — Objetiva
No Python, o que a função input() sempre devolve?

A.	Um número inteiro

B.	Um booleano (True/False) a

C.	Uma string (texto). correta

D.	Uma lista


Questão 2 — Justificativa
Explique, em 3–5 linhas, por que a API key deve ficar no arquivo .env e não escrita direto no código .py. Cite pelo menos um risco concreto se a key for exposta.

Questão 3 — Objetiva
Observe o trecho:
 
 
O que historico é?

A.	Uma string

B.	Uma lista de dicionários. correto

C.	Um número

D.	Uma função 

Questão 5 — Justificativa + conceito
Na aula do chat sem histórico, se a pessoa digita:
1. Meu nome é Ana
2. Qual é o meu nome?
o modelo costuma não lembrar.
a. Por que isso acontece? (2–4 linhas):Isso acontece porque o modelo não guarda automaticamente as mensagens de conversas anteriores.
b. O que mudamos no código para o modelo passar a lembrar? Cite a estrutura de dados usada:Adicionamos uma estrutura de dados chamada lista de dicionários, denominada historico, para armazenar as mensagens anteriores. A

Questão 6 — Objetiva (API / JSON)
Depois de uma chamada bem-sucedida à API (status 200), o texto da resposta fica em:
dados["choices"][0]["message"]["content"]
O que significa o [0] nesse caminho?
A. É o nome do modelo
B. Pega o primeiro item da lista choices. correto
C. É a API key
D. Apaga a mensagem do usuário