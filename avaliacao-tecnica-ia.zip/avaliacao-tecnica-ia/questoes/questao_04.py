"""Questão 4: soma números até o usuário digitar 0."""


def somar_entradas():
    total = 0

    while True:
        try:
            n = int(input("Número (0 para sair): "))
        except ValueError:
            print("Digite um número inteiro válido.")
            continue

        if n == 0:
            break

        total += n

    print(f"Soma: {total}")
    return total


if __name__ == "__main__":
    somar_entradas()
