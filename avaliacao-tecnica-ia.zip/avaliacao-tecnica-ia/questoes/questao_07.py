"""Questão 7: leitura segura de um arquivo de contexto."""


def carregar_contexto(caminho="contexto.txt"):
    """Lê o contexto em UTF-8; retorna string vazia se o arquivo não existir."""
    try:
        with open(caminho, "r", encoding="utf-8") as arquivo:
            return arquivo.read().strip()
    except FileNotFoundError:
        print(f"Aviso: o arquivo '{caminho}' não foi encontrado.")
        return ""


if __name__ == "__main__":
    contexto = carregar_contexto()
    if contexto:
        print("Contexto carregado:")
        print(contexto)
